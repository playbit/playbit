// Native and Wasm ABI adapters opt out locally; all other SDK code denies unsafe.
#![deny(unsafe_code, clippy::unwrap_used)]

pub mod abi;
pub mod ui;

pub mod context;

#[cfg(any(feature = "guest", test))]
mod app;
#[cfg(all(not(target_arch = "wasm32"), any(feature = "guest", test)))]
pub use app::native_app;
#[cfg(any(feature = "guest", test))]
pub use app::{App, app};
